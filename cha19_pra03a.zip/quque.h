#ifndef __QUQUE_H__
#define __QUQUE_H__

#define QUQUE_LEN 5

typedef int INPUT_TYPE;
typedef struct quque_type *Quque;
typedef enum qbool { FALSE, TRUE } qbool;

Quque create_quque(void);
void destory_quque(Quque);
void in_quque(Quque, INPUT_TYPE);
void out_quque(Quque);
qbool is_empty(Quque);
INPUT_TYPE last_item(Quque);
INPUT_TYPE first_item(Quque);

#endif