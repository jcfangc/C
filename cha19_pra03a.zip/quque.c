#include "quque.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct quque_type {
    INPUT_TYPE quque[QUQUE_LEN];
    int add_index;
    int delete_index;
    int total;
} quque_type;

// ��������
Quque create_quque(void)
{
    Quque new_quque = calloc(1, sizeof(quque_type));
    if (new_quque != NULL) {
        return new_quque;
    }
    else {
        printf("\t No memery avalible. \n");
        getchar();
        exit(EXIT_FAILURE);
    }
}
// ���ٶ���
void destory_quque(Quque q)
{
    free(q);
}
// �����ĩ�˼�����
void in_quque(Quque q, INPUT_TYPE d)
{
    if (q->total >= QUQUE_LEN) {
        printf("\t Quque is full.\n");
        return;
    }
    else {
        (q->quque)[q->add_index] = d;
        q->total++;
        q->add_index = q->total;
    }
}
// �Ӷ���ǰ��������
void out_quque(Quque q)
{
    if (q->total > 0) {
        printf("\t %d is being deleted.\n", (q->quque)[q->delete_index]);
        for (int i = q->delete_index; i < q->total - 1; i++) {
            (q->quque)[i] = (q->quque)[i + 1];
        }
        q->add_index--;
        q->total--;
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}
// ��ѯ���������Ƿ�Ϊ��
qbool is_empty(Quque q)
{
    return(q->total == 0 ? TRUE : FALSE);
}
// ����ĩ��
INPUT_TYPE last_item(Quque q)
{
    if (q->total > 0) {
        return (q->quque)[q->total - 1];
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}
// ��������
INPUT_TYPE first_item(Quque q)
{
    if (q->total > 0) {
        return (q->quque)[q->delete_index];
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}