#ifndef QUICKSORT_H
#define QUICKSORT_H

int split(int[], int, int);
void quicksort(int[], int, int);

#endif