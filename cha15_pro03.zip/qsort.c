#include <stdio.h>
#include "quicksort.h"

#define N 10

int main(void)
{
    int a[N], i;

    printf("\n\t Enter %d numbers to be sorted: ", N);
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    getchar(); // '\n'

    quicksort(a, 0, N - 1);

    printf("\n\t In sorted order: ");
    for (i = 0; i < N; i++) {
        printf("%d", a[i]);
    }
    printf("\n");

    return 0;
}