// �޸� 15.3 �ڵĳ��� justify�����±�д line.c �ļ�ʹ��洢�����еĵ�ǰ�С������е�ÿ���ڵ�洢һ�����ʡ���һ��ָ�������һ�����ʵĽ���ָ��������滻ԭ�е� line ���飬����Ϊ��ʱ�ñ����洢��ָ�롣
// �������ȡ��������ԭ���ĳ�����иı�

/*********************************************************
 * From C PROGRAMMING: A MODERN APPROACH, Second Edition *
 * By K. N. King                                         *
 * Copyright (c) 2008, 1996 W. W. Norton & Company, Inc. *
 * All rights reserved.                                  *
 * This program may be freely distributed for class use, *
 * provided that this copyright notice is retained.      *
 *********************************************************/

 /* line.h (Chapter 15, page 362) */

#ifndef LINE_H
#define LINE_H

typedef struct line *Line;

/**********************************************************
 * clear_line: Clears the current line.                   *
 **********************************************************/
void clear_line(Line);

/**********************************************************
 * add_word: Adds word to the end of the current line.    *
 *           If this is not the first word on the line,   *
 *           puts one space before word.                  *
 **********************************************************/
void add_word(Line, const char *);

/**********************************************************
 * space_remaining: Returns the number of characters left *
 *                  in the current line.                  *
 **********************************************************/
int space_remaining(Line);

/**********************************************************
 * write_line: Writes the current line with               *
 *             justification.                             *
 **********************************************************/
void write_line(Line);

/**********************************************************
 * flush_line: Writes the current line without            *
 *             justification. If the line is empty, does  *
 *             nothing.                                   *
 **********************************************************/
void flush_line(Line);

Line create(void);
void destory(Line);

#endif
