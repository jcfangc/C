#include <stdio.h>
#include <string.h>
#include "readline.h"

#define MAX_REMIND 50
#define MSG_LEN 60

int main(void)
{
    char reminds[MAX_REMIND][MSG_LEN + 3];
    char day_str[3], msg_str[MSG_LEN + 1];
    int day, i, j, num_remind = 0;

    for (;;) {
        if (num_remind == MAX_REMIND) {
            printf("\n\t -- No space left --");
            break;
        }

        printf("\n\t Enter day and reminder: ");
        scanf("%2d", &day);
        if (day == 0) {
            getchar(); // '\n'
            break;
        }
        sprintf(day_str, "%2d", day);
        read_line(msg_str, MSG_LEN);

        for (i = 0; i < num_remind; i++) {
            if (strcmp(day_str, reminds[i]) < 0) {
                break;
            }
        }
        for (j = num_remind; j > i; j--) {
            strcpy(reminds[j], reminds[j - 1]);
        }

        strcpy(reminds[i], day_str);
        strcat(reminds[i], msg_str);

        num_remind++;
    }

    printf("\nDay Reminder\n");
    for (i = 0; i < num_remind; i++) {
        printf("%s\n", reminds[i]);
    }

    getchar();
    return 0;
}

// 这两题题目本身没有非常多的困难，主要让笔者头疼的是如何调试多个文件。以下是我参考的很多有用的信息源：
// https://blog.csdn.net/hzf978742221/article/details/116101789
// https://blog.csdn.net/vaemusicsky/article/details/100577511
// https://blog.csdn.net/qq_42239488/article/details/117787373
// https://zhuanlan.zhihu.com/p/520486342
// https://blog.csdn.net/weixin_43870522/article/details/105736474