#ifndef READLINE_H
#define READLINE_H

int read_line(char[], int);

#endif