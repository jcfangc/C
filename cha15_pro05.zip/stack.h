#ifndef STACK_H
#define STACK_H

#define STACK_SIZE 100
#define TOP 0

int push(int[], int, int);
int pop(int[], int, int);

#endif