#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

// �ⲿ����
int stack_index = 0;

int push(int arr[], int size, int num)
{
    // ��ջԪ�����¼�ѹ��������λ
    if (stack_index > TOP && stack_index < size) {
        for (int i = stack_index - 1; i >= TOP; i--) {
            arr[i + 1] = arr[i];
        }
    }
    else if (stack_index == size) {
        printf("\n\t Stack overflow. Program ends. ");
        while (getchar() != '\n') {
            ;
        }
        getchar(); // end program
        exit(EXIT_FAILURE);
    }

    // ѹ����Ԫ��
    arr[TOP] = num;
    stack_index++;

    // ����Ŀǰindex
    return stack_index;
}

int pop(int arr[], int size, int index)
{
    int popnum = arr[TOP];

    // Ԫ���ƶ�
    if (stack_index > TOP && stack_index < STACK_SIZE) {
        for (int i = TOP; i < stack_index; i++) {
            arr[i] = arr[i + 1];
        }
    }
    else if (stack_index == TOP) {
        printf("\n\t Stack underflow. Program ends. ");
        getchar(); // '\n'
        getchar(); // end program
        exit(EXIT_FAILURE);
    }

    // ���ص���Ԫ��
    stack_index--;
    return popnum;
}