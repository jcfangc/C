#include "quque.h"
#include <stdlib.h>
#include <stdio.h>

// ����������������һ��ָ�����ĩ�˵Ľڵ㣬�ڴ˾Ͳ��������������ˡ�
Quque head;

typedef struct quque_type {
    INPUT_TYPE data;
    Quque last_item;
} quque_type;

// ���ٶ���
void destory_quque(Quque *q)
{
    Quque temp = *q;
    while (temp != NULL) {
        *q = (*q)->last_item;
        free(temp);
        temp = *q;
    }
}
// �����ĩ�˼�����
void in_quque(Quque *tail, INPUT_TYPE d)
{
    if (*tail == NULL) {
        Quque new_quque = calloc(1, sizeof(quque_type));
        if (new_quque != NULL) {
            new_quque->last_item = NULL;
            new_quque->data = d;
            *tail = new_quque;
            head = new_quque;
        }
        else {
            printf("\t No memery avalible. \n");
            getchar();
            exit(EXIT_FAILURE);
        }
    }
    else {
        Quque new_item = malloc(sizeof(quque_type));
        if (new_item == NULL) {
            printf("\t No memory avalible.\n");
            getchar();
            exit(EXIT_FAILURE);
        }
        else {
            new_item->data = d;
            new_item->last_item = *tail;
            *tail = new_item;
        }
    }
}
// �Ӷ���ǰ��������
void out_quque(Quque *q)
{
    if (*q != NULL) {
        printf("\t %d is being deleted.\n", head->data);
        Quque temp = *q;
        if (temp != head) {
            while (temp->last_item != head) {
                temp = temp->last_item;
            }
            temp->last_item = NULL;
            free(head);
            head = temp;
        }
        else {
            *q = NULL;
            free(temp);
            head = NULL;
        }
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}
// ��ѯ���������Ƿ�Ϊ��
qbool is_empty(Quque q)
{
    return(q == NULL ? TRUE : FALSE);
}
// ����ĩ��
INPUT_TYPE last_item(Quque q)
{
    if (q != NULL) {
        return q->data;
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}
// ��������
INPUT_TYPE first_item(Quque q)
{
    if (q != NULL) {
        return head->data;
    }
    else {
        printf("\t The quque is empty.\n");
        getchar();
        exit(EXIT_FAILURE);
    }
}