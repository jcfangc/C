#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "makelist.h"

struct node *print_list(struct node *head)
{
    struct node *temp = head;
    int count = 0;

    while (temp != NULL) {
        temp = temp->next;
        count++;
    }

    // ��������ӡ����
    temp = head;
    for (int i = count; (i >= 1) && (temp != NULL); i--, temp = temp->next) {
        printf("\n\t No.%d \n\t Value: %d \n\t Address: %p \n\t | \n\t | ", i, temp->value, temp);
    }
    printf("\n\t No.0 \n\t Value: NULL \n");

    return head;
}

struct node *ordered_list_maker(int length)
{
    struct node *head = NULL;

    // �����������������
    for (int i = 1; i <= length; i++) {
        head = new_node_to_list(i, head);
    }

    // ��������ӡ����
    struct node *temp = head;
    for (int i = length; (i >= 1) && (temp != NULL); i--, temp = temp->next) {
        printf("\n\t No.%d \n\t Value: %d \n\t Address: %p \n\t | \n\t | ", i, temp->value, temp);
    }
    printf("\n\t No.0 \n\t Value: NULL \n");

    return head;
}

struct node *list_maker(int length)
{
    struct node *head = NULL;

    srand((unsigned)time(NULL));

    // �����������������
    for (int i = 1; i <= length; i++) {
        head = new_node_to_list((rand() % LIMIT), head);
    }

    // ��������ӡ����
    struct node *temp = head;
    for (int i = length; (i >= 1) && (temp != NULL); i--, temp = temp->next) {
        printf("\n\t No.%d \n\t Value: %d \n\t Address: %p \n\t | \n\t | ", i, temp->value, temp);
    }
    printf("\n\t No.0 \n\t Value: NULL \n");

    return head;
}

struct node *new_node_to_list(int value, struct node *head)
{
    struct node *new_node = malloc(sizeof(struct node));

    if (new_node != NULL) {
        new_node->value = value;
        new_node->next = head;
        return new_node;
    }
    else {
        printf("\n\t No memory space avalible. ");
        exit(EXIT_SUCCESS);
    }
}

struct node *clean_list(struct node *list)
{
    struct node *temp;

    while (list != NULL) {
        temp = list;
        list = list->next;
        free(temp);
    }

    return list;
}

struct node *list_inverse(struct node *list)
{
    struct node *inverse = NULL, *temp;
    int count = 0;

    while (list != NULL) {
        temp = list;
        list = list->next;
        temp->next = inverse;
        inverse = temp;
        count++;
    }

    // ������������ӡ����
    temp = inverse;
    printf("\n\n\t The list is inversed: \n\t ------------------------------------------------");
    for (int i = count; (i >= 1) && (temp != NULL); i--, temp = temp->next) {
        printf("\n\t No.%d \n\t Value: %d \n\t Address: %p \n\t | \n\t | ", i, temp->value, temp);
    }
    printf("\n\t No.0 \n\t Value: NULL \n");

    return inverse;
}