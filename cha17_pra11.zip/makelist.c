#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "makelist.h"

struct node *list_maker(int length)
{
    struct node *head = NULL;

    srand((unsigned)time(NULL));

    // �����������������
    for (int i = 1; i <= length; i++) {
        head = new_node_to_list((rand() % LIMIT), head);
    }

    // ��������ӡ����
    struct node *temp = head;
    for (int i = length; (i >= 1) && (temp != NULL); i--, temp = temp->next) {
        printf("\n\t No.%d \n\t Value: %d \n\t | \n\t | ", i, temp->value);
    }
    printf("\n\t No.0 \n\t Value: NULL");

    return head;
}

struct node *new_node_to_list(int value, struct node *head)
{
    struct node *new_node = malloc(sizeof(struct node));

    if (new_node != NULL) {
        new_node->value = value;
        new_node->next = head;
        return new_node;
    }
    else {
        printf("\n\t No memory space avalible. ");
        exit(EXIT_SUCCESS);
    }
}